<?php
$server = "trinetra";
$user = "tekh7457_admin";
$pass = "T3kun1n@!";
$database = "tekh7457_users";
$conn = mysqli_connect($server, $user, $pass, $database);
if (!$conn) {
    die("Koneksi ke database gagal: " . mysqli_connect_error());
}
?>